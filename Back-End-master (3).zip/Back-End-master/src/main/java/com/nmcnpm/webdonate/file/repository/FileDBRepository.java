package com.nmcnpm.webdonate.file.repository;

import com.nmcnpm.webdonate.file.model.FileDB;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileDBRepository extends JpaRepository<FileDB,String> {
    @Query(value = "SELECT * FROM file f WHERE f.type = 'image/gif'", nativeQuery = true)
    List<FileDB> findAllFileGif();

    @Query(value = "SELECT * FROM file f WHERE f.type = 'audio/mpeg'", nativeQuery = true)
    List<FileDB> findAllFileMp3();
}
