package com.nmcnpm.webdonate.donate.entity;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "momo")
public class MomoClient {

    @Id
    private String nameId;

    @OneToMany(mappedBy = "nameDonate", cascade = CascadeType.ALL)
    private List<Donate> donateList = new ArrayList<>();

    private boolean status;


    public String getNameId() {
        return nameId;
    }

    public void setNameId(String nameId) {
        this.nameId = nameId;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
