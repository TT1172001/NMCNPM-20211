package com.nmcnpm.webdonate.setting.controller;

import com.google.gson.Gson;
import com.nmcnpm.webdonate.setting.model.Setting;
import com.nmcnpm.webdonate.setting.service.SettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/setting")
@CrossOrigin(origins = "*")
public class controller {

    @Autowired
    SettingService settingService;

    @GetMapping
    public ArrayList<Setting> getSetting(){
        ArrayList<Setting> listSetting = (ArrayList<Setting>) settingService.getAllSetting();
        return listSetting;
    }

    @PutMapping
    public ResponseEntity<String> editSetting(@RequestBody Setting setting){
        try {
            settingService.editSetting(setting);
            return ResponseEntity.status(HttpStatus.OK).body(new String("edit setting successfully"));
        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new String("fail"));
        }
    }

    @PostMapping
    public ResponseEntity<String> saveSetting(@RequestBody Setting setting) {
        try {
            Setting settingRespone = settingService.saveSetting(setting);
            return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(settingRespone).toString());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("fail (look your id)");

        }
    }
    @DeleteMapping
    public ResponseEntity<String> deleteSetting(@RequestBody int settingId) {
        try {
            settingService.deleteSetting(settingId);
            return ResponseEntity.status(HttpStatus.OK).body(new String("Delete setting successfully"));
        }
        catch (Exception e){
//            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new String("No class entity with id exists!"));
        }

    }
}