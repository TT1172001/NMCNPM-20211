package com.nmcnpm.webdonate.donate.service;

import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.model.DonateDayDto;
import com.nmcnpm.webdonate.donate.model.DonateMonthDto;
import com.nmcnpm.webdonate.donate.model.TopDonateMomo;

import java.util.ArrayList;
import java.util.List;

public interface DonateService{
    public Donate saveDonate(Donate donate);
    public ArrayList<Donate> findAll();
    public ArrayList<DonateDayDto> findMonth(int month, int year);
    public ArrayList<DonateMonthDto> findYear(int year);

    public ArrayList<TopDonateMomo> findTopDay(int day, int month, int year);
    public ArrayList<TopDonateMomo> findTopWeek(int  day, int month, int year);
    public ArrayList<TopDonateMomo> findTopMonth(int month, int year);

    public ArrayList<Donate> findAllMomoDonate();
    public ArrayList<Donate> findAllBankingDonate();

}
