package com.nmcnpm.webdonate.texttospeech.textospeechgoogle;

import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.texttospeech.v1beta1.*;
import com.google.protobuf.ByteString;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
@Service
public class TextToSpeechGoogleImp implements TextToSpeechGoogle{

    @Override
    public byte[] getSpeech(String text){

        // xác minh google
        TextToSpeechSettings textToSpeechSettings = null;
        try{
            FileInputStream credentialsStream = new FileInputStream("round-bruin-314916-ef37d092054c.json");
            GoogleCredentials credentials = GoogleCredentials.fromStream(credentialsStream);
            FixedCredentialsProvider credentialsProvider = FixedCredentialsProvider.create(credentials);

            textToSpeechSettings =
                    TextToSpeechSettings.newBuilder()
                            .setCredentialsProvider(credentialsProvider)
                            .build();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (TextToSpeechClient textToSpeechClient = TextToSpeechClient.create(textToSpeechSettings)) {
            // Set the text input to be synthesized
            SynthesisInput input = SynthesisInput.newBuilder().setText(text).build();

            // Build the voice request; languageCode = "vi-VN"
            VoiceSelectionParams voice = VoiceSelectionParams.newBuilder().setLanguageCode("vi-VN")
                    .setSsmlGender(SsmlVoiceGender.FEMALE)
                    .build();

            // Select the type of audio file you want returned
            AudioConfig audioConfig = AudioConfig.newBuilder().setAudioEncoding(AudioEncoding.MP3) // MP3 audio.
                    .build();

            // Perform the text-to-speech request
            SynthesizeSpeechResponse response = textToSpeechClient.synthesizeSpeech(input, voice, audioConfig);

            // Get the audio contents from the response
            ByteString audioContents = response.getAudioContent();

            byte[] check=audioContents.toByteArray();
            return check;
        }catch (Exception e) {
            return null;
        }
    }
}
