package com.nmcnpm.webdonate.donate.model;public class AllBankingDonateDto {
}
