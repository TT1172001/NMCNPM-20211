package com.nmcnpm.webdonate.setting.repository;


import com.nmcnpm.webdonate.setting.model.Setting;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SettingCurdRepository extends CrudRepository<Setting, Integer> {
    Setting findById(int id);
}