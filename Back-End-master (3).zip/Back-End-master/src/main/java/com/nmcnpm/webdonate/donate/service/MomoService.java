package com.nmcnpm.webdonate.donate.service;

import com.nmcnpm.webdonate.donate.entity.MomoClient;

import java.util.List;

public interface MomoService {
    public MomoClient saveMomo (MomoClient momoClient);
    public List<MomoClient> getAllMomo();
    public boolean checkID(String nameId);
}
