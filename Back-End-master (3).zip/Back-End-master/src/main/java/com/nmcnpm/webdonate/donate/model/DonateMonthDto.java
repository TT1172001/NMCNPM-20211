package com.nmcnpm.webdonate.donate.model;

public class DonateMonthDto {
    private int month;
    private long  total_donate;

    public DonateMonthDto(int month, long total_donate){
        this.month=month;
        this.total_donate=total_donate;
    }

    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }
    public long getTotal_donate() {
        return total_donate;
    }
    public void setTotal_donate(long total_donate) {
        this.total_donate = total_donate;
    }
}
