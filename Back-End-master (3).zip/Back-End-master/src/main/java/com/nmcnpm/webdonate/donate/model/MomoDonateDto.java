package com.nmcnpm.webdonate.donate.model;

public class MomoDonateDto {

    private long money;
    private int day;
    private int month;
    private int year;
    private String nameID_Momo;

    public long getMoney() {
        return money;
    }
    public String getNameID_Momo() {
        return nameID_Momo;
    }
    public void setNameID_Momo(String nameID_Momo) {
        this.nameID_Momo = nameID_Momo;
    }
    public void setMoney(long money) {
        this.money = money;
    }
    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
}
