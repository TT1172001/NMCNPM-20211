package com.nmcnpm.webdonate.donate.repository;

import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.model.TopDonateMomo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.util.List;


@Repository
public interface DonateRepository extends JpaRepository<Donate, Integer> {
    @Query("SELECT Sum(d.money) FROM  Donate d WHERE YEAR(d.date)=?1 and MONTH(d.date) = ?2")
    Long getTotalDonateMonth(int year, int month);

    @Query("SELECT Sum(d.money) FROM  Donate d WHERE YEAR(d.date)=?1 and MONTH(d.date) = ?2 and DAY(d.date)=?3")
    Long getTotalDonateDay(int year, int month, int day);

    @Query(value = "SELECT * FROM donate d WHERE (d.banking_number is null) and  not(d.name_id is null)", nativeQuery = true)
    List<Donate> getAllMomoDonate();

    @Query(value = "SELECT * FROM donate d WHERE not(d.banking_number is null) and  (d.name_id is null)", nativeQuery = true)
    List<Donate> getAllBankingDonate();


    @Query(value ="select d.name_id as nameID_Momo, sum(d.money) as sumMoney\n" +
            "from donate d\n" +
            "where day(d.date) = ?1\n" +
            "      and month(d.date) = ?2\n" +
            "      and year(d.date) = ?3\n" +
            "      and d.name_id is not null\n" +
            "group by d.name_id\n" +
            "order by sumMoney desc\n" +
            "limit 5", nativeQuery = true)
    List<TopDonateMomo> getTopDonateDay(int day, int month, int year);

    @Query(value ="select d.name_id as nameID_Momo, sum(d.money) as sumMoney\n" +
            "from donate d\n" +
            "where week(d.date) = week(concat(?3, '-', ?2, '-', ?1))\n" +
            "\t  and year(d.date) = 2021\n" +
            "      and d.name_id is not null\n" +
            "group by d.name_id\n" +
            "order by sumMoney desc\n" +
            "limit 5", nativeQuery = true)
    List<TopDonateMomo> getTopDonateWeek(int day, int month, int year);

    @Query(value ="select d.name_id as nameID_Momo, sum(d.money) as sumMoney\n" +
            "from donate d\n" +
            "where month(d.date) = ?1\n" +
            "      and year(d.date) = ?2\n" +
            "      and d.name_id is not null\n" +
            "group by d.name_id\n" +
            "order by sumMoney desc\n" +
            "limit 5", nativeQuery = true)
    List<TopDonateMomo> getTopDonateMonth(int month, int year);
}
