package com.nmcnpm.webdonate.donate.mapstruct;


import com.nmcnpm.webdonate.donate.entity.BankClient;
import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.entity.MomoClient;
import com.nmcnpm.webdonate.donate.model.DonateAllDto;
import com.nmcnpm.webdonate.donate.model.DonateDto;
import com.nmcnpm.webdonate.donate.model.BankingDonateDto;
import com.nmcnpm.webdonate.donate.model.MomoDonateDto;

import org.mapstruct.Mapper;

import java.util.List;

@Mapper(
        componentModel = "spring"
)
public interface MapStructMapper {

    public DonateDto dataToDonateDto(String data);
    public MomoClient donateDtoToMomoClient(DonateDto donateDto);
    public BankClient donateDtoToBankClient(DonateDto donateDto);
    public Donate donateDtoMomoToDonate(DonateDto donateDto, MomoClient momoClient);

    MomoDonateDto donateToMomoDonateDto(Donate donate);
    List<MomoDonateDto> donatesToMomoDonateDtos(List<Donate> donates);

    BankingDonateDto donateToBankingDonateDto(Donate donate);
    List<BankingDonateDto> donatesToBankingDonateDtos(List<Donate> donates);

}
