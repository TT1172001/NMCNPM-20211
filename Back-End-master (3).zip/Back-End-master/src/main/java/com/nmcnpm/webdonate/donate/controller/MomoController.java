package com.nmcnpm.webdonate.donate.controller;

import com.nmcnpm.webdonate.donate.entity.MomoClient;
import com.nmcnpm.webdonate.donate.service.MomoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/momo")
@CrossOrigin(origins = "*")
public class MomoController {
    @Autowired
    private MomoService momoService;

    @PostMapping
    public ResponseEntity<MomoClient> saveMomo (@RequestBody MomoClient momoClient){
        momoService.saveMomo(momoClient);
        try {

            return ResponseEntity.status(HttpStatus.OK).body(momoClient);
        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(null);
        }
    }

    @GetMapping
    public ArrayList<MomoClient> getMomo(){
        return (ArrayList<MomoClient>) momoService.getAllMomo();
    }

}
