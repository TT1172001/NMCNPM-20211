package com.nmcnpm.webdonate.donate.repository;

import com.nmcnpm.webdonate.donate.entity.MomoClient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MomoRepository extends JpaRepository<MomoClient, String> {
}
