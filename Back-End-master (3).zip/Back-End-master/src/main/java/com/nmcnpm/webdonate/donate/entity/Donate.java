package com.nmcnpm.webdonate.donate.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "donate")
public class Donate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "name_id")
    private MomoClient nameDonate;

    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name = "banking_number")
    private BankClient bankingNumber;

    private  String content;
    private Date date;
    private long money;

    public BankClient getBankingNumber() {
        return bankingNumber;
    }

    public void setBankingNumber(BankClient bankingNumber) {
        this.bankingNumber = bankingNumber;
    }

    public MomoClient getNameDonate() {
        return nameDonate;
    }

    public void setNameDonate(MomoClient nameDonate) {
        this.nameDonate = nameDonate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getMoney() {
        return money;
    }

    public void setMoney(long money) {
        this.money = money;
    }
}
