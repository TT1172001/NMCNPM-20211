package com.nmcnpm.webdonate.texttospeech.controller;

import com.nmcnpm.webdonate.file.message.ResponseMessage;
import com.nmcnpm.webdonate.texttospeech.message.ResponseFileTextToSpeech;
import com.nmcnpm.webdonate.texttospeech.textospeechgoogle.TextToSpeechGoogle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/text_to_speech")
@CrossOrigin(origins = "*")
public class TextToSpeechController {
    @Autowired
    private TextToSpeechGoogle textToSpeechGoogle;

    @GetMapping()
    public ResponseEntity<byte[]> getSpeechGoogle(@RequestParam(name="text") String text) {
        try{
            ResponseFileTextToSpeech fileTextToSpeech = new ResponseFileTextToSpeech("Speech.mp3","mp3",textToSpeechGoogle.getSpeech(text)) ;
            System.out.println("get file");
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileTextToSpeech.getName() + "\"")
                    .body(fileTextToSpeech.getData());
        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(null);
        }

    }
}