package com.nmcnpm.webdonate.donate.controller;

import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.mapstruct.MapStructMapper;
import com.nmcnpm.webdonate.donate.model.*;
import com.nmcnpm.webdonate.donate.service.DonateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/donate")
@CrossOrigin(origins = "*")
public class DonateController {
    private DonateService donateService;
    private MapStructMapper mapstructMapper;

    @Autowired
    public DonateController(MapStructMapper mapstructMapper,DonateService donateService){
        this.mapstructMapper = mapstructMapper;
        this.donateService = donateService;
    }

    @PostMapping("/add")
    public String add(@RequestBody Donate donate){
        donateService.saveDonate(donate);
        return "new donate";
    }
    @GetMapping("/data_all_momo_donate")
    public List<MomoDonateDto> getAllMomoDonate(){
        List<MomoDonateDto> listDonates = mapstructMapper.donatesToMomoDonateDtos( donateService.findAllMomoDonate() ) ;
        return listDonates;
    }
    @GetMapping("/data_all_banking_donate")
    public List<BankingDonateDto> getAllBankingDonate(){
        List<BankingDonateDto> listDonates = mapstructMapper.donatesToBankingDonateDtos( donateService.findAllBankingDonate() ) ;
        return listDonates;
    }

    @GetMapping("/total_donate_by_year")
    public List<DonateMonthDto> getTotalYear(@RequestParam(name="year") int year){
        ArrayList<DonateMonthDto> listDonates = donateService.findYear(year) ;
        return listDonates;
    }

    @GetMapping("/total_donate_by_month")
    public List<DonateDayDto> getTotalMonth(@RequestParam(name="month") int month, @RequestParam(name="year") int year){
        ArrayList<DonateDayDto> listDonates = donateService.findMonth(month,year) ;
        return listDonates;
    }

    @GetMapping("/top_donate_by_day")
    public List<TopDonateMomo> topDonateByDay(@RequestParam(name="day") int day, @RequestParam(name="month") int month, @RequestParam(name="year") int year){
        ArrayList<TopDonateMomo> listDonates = donateService.findTopDay(day, month, year) ;
        return listDonates;
    }
    @GetMapping("/top_donate_by_week")
    public List<TopDonateMomo> topDonateByWeek(@RequestParam(name="day") int day, @RequestParam(name="month") int month, @RequestParam(name="year") int year){
        ArrayList<TopDonateMomo> listDonates = donateService.findTopWeek(day, month, year) ;
        return listDonates;
    }
    @GetMapping("/top_donate_by_month")
    public List<TopDonateMomo> topDonateByMonth( @RequestParam(name="month") int month, @RequestParam(name="year") int year){
        ArrayList<TopDonateMomo> listDonates = donateService.findTopMonth(month, year) ;
        return listDonates;
    }
}
