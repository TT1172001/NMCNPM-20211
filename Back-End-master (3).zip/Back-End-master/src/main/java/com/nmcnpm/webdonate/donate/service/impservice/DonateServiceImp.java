package com.nmcnpm.webdonate.donate.service.impservice;

import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.model.*;
import com.nmcnpm.webdonate.donate.repository.DonateRepository;
import com.nmcnpm.webdonate.donate.service.DonateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DonateServiceImp implements DonateService {
    @Autowired
    private DonateRepository donateRepository;

    @Override
    public Donate saveDonate(Donate donate) {
        return donateRepository.save(donate);
    }

    @Override
    public ArrayList<Donate> findAll() {
        ArrayList<Donate> list = (ArrayList<Donate>) donateRepository.findAll();
        return list;
    }
    @Override
    public ArrayList<Donate> findAllMomoDonate() {
        ArrayList<Donate> list = (ArrayList<Donate>) donateRepository.getAllMomoDonate();
        return list;
    }
    @Override
    public ArrayList<Donate> findAllBankingDonate() {
        ArrayList<Donate> list = (ArrayList<Donate>) donateRepository.getAllBankingDonate();
        return list;
    }
    @Override
    public  ArrayList<DonateDayDto> findMonth(int month, int year) {
        int daysInMonth;

        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                daysInMonth = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                daysInMonth = 30;
                break;
            case 2:
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
                    daysInMonth = 29;
                    break;
                } else {
                    daysInMonth = 28;
                    break;
                }
            default:
                daysInMonth = 30;
        }
        ArrayList<DonateDayDto> listJsons = new ArrayList<>();

        for (int day=1;day<=daysInMonth;day++) {
            if (donateRepository.getTotalDonateDay(year,month,day)==null) listJsons.add(new DonateDayDto(day,0));
            else listJsons.add(new DonateDayDto(day,donateRepository.getTotalDonateDay(year,month,day)));
        }
        return listJsons;
    }

    @Override
    public  ArrayList<DonateMonthDto> findYear(int year) {
        ArrayList<DonateMonthDto> listJsons = new ArrayList<>();
        for (int month=1;month<=12;month++) {
            if (donateRepository.getTotalDonateMonth(year,month)==null) listJsons.add(new DonateMonthDto(month,0));
            else listJsons.add(new DonateMonthDto(month,donateRepository.getTotalDonateMonth(year,month)));
        }
        return listJsons;
    }
    @Override
    public  ArrayList<TopDonateMomo> findTopDay(int day, int month, int year) {
        ArrayList<TopDonateMomo> list = (ArrayList<TopDonateMomo>) donateRepository.getTopDonateDay(day, month, year);
        return list;
    }
    @Override
    public  ArrayList<TopDonateMomo> findTopWeek(int day, int month, int year) {
        ArrayList<TopDonateMomo> list = (ArrayList<TopDonateMomo>) donateRepository.getTopDonateWeek(day, month, year);
        return list;
    }
    @Override
    public  ArrayList<TopDonateMomo> findTopMonth(int month, int year) {
        ArrayList<TopDonateMomo> list = (ArrayList<TopDonateMomo>) donateRepository.getTopDonateMonth(month, year);
        return list;
    }

}
