package com.nmcnpm.webdonate.donate.model;

public interface TopDonateMomo {
    String getNameID_Momo();
    long getSumMoney();
}
