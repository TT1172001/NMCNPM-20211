package com.nmcnpm.webdonate.texttospeech.textospeechgoogle;

public interface TextToSpeechGoogle {
    public byte[] getSpeech(String text);
}
