package com.nmcnpm.webdonate.donate.service.impservice;

import com.nmcnpm.webdonate.donate.entity.MomoClient;
import com.nmcnpm.webdonate.donate.repository.MomoRepository;
import com.nmcnpm.webdonate.donate.service.MomoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MomoServiceImp implements MomoService {

    @Autowired
    private MomoRepository momoRepository;

    @Override
    public MomoClient saveMomo(MomoClient momoClient) {
        return momoRepository.save(momoClient);
    }

    @Override
    public ArrayList<MomoClient> getAllMomo() {
        return (ArrayList<MomoClient>) momoRepository.findAll();
    }

    @Override
    public boolean checkID(String nameId){
        return momoRepository.existsById(nameId);
    }
}
