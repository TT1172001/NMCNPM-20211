package com.nmcnpm.webdonate.setting.service;

import com.nmcnpm.webdonate.setting.model.Setting;
import com.nmcnpm.webdonate.setting.repository.SettingRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface SettingService {
    public Setting saveSetting(Setting setting);
    public void deleteSetting(int setting);
    public boolean editSetting(Setting setting);
    public List<Setting> getAllSetting();
}