package com.nmcnpm.webdonate.apicontroller.apiandroid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping(value = "/mess")
@CrossOrigin(origins = "*")
public class RecvAndroid {
    private static final String URL = "ws://web-donate.herokuapp.com/andoird";
    //private static final String URL = "ws://localhost:8080/andoird";

    @PostMapping
    public ResponseEntity<String> RecvMess(@RequestBody String mess) throws ExecutionException, InterruptedException {
        try {
            SendWebSocket(mess);
            return ResponseEntity.status(HttpStatus.OK).body("OK");
        }
        catch (Exception e){
            return ResponseEntity.status(HttpStatus.FAILED_DEPENDENCY).body("fail");
        }

    }

    private void SendWebSocket (String mess) throws ExecutionException, InterruptedException {
        WebSocketClient webSocketClient = new StandardWebSocketClient();
        WebSocketStompClient stompClient = new WebSocketStompClient(webSocketClient);
        stompClient.setMessageConverter(new MappingJackson2MessageConverter());
        StompSessionHandler sessionHandler = new CustomStompSessionHandler();
        StompSession stompSession = stompClient.connect(URL, sessionHandler).get();
        stompSession.send("/app/hello", mess);
        stompSession.disconnect();
        stompClient.stop();
    }
}
