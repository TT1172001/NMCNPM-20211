package com.nmcnpm.webdonate.donate.model;

public class DonateAllDto {

    private long money;
    private int day;
    private int month;
    private int year;
    private String banking_number;
    private String name_banking;
    private String nameID_Momo;

    public String getName_banking() {
        return name_banking;
    }

    public void setName_banking(String name_banking) {
        this.name_banking = name_banking;
    }

    public long getMoney() {
        return money;
    }

    public String getNameID_Momo() {
        return nameID_Momo;
    }

    public void setNameID_Momo(String nameID_Momo) {
        this.nameID_Momo = nameID_Momo;
    }

    public void setMoney(long money) {
        this.money = money;
    }
    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public int getMonth() {
        return month;
    }
    public void setMonth(int month) {
        this.month = month;
    }
    public int getYear() {
        return year;
    }
    public void setYear(int year) {
        this.year = year;
    }
    public String getBanking_number() {
        return banking_number;
    }
    public void setBanking_number(String banking_number) {
        this.banking_number = banking_number;
    }
}
