package com.nmcnpm.webdonate.donate.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "bank")
public class BankClient {

    @Id
    private String bankingNumber;

    @OneToMany(mappedBy = "bankingNumber")
    private List<Donate> donateList = new ArrayList<>();

    private String name;
    private boolean status;

    public String getBankingNumber() {
        return String.valueOf(bankingNumber);
    }

    public void setBankingNumber(String bankingNumber) {
        this.bankingNumber = bankingNumber;
    }

    public String getName() {
        return String.valueOf(name);
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
