package com.nmcnpm.webdonate.file.service;

import com.nmcnpm.webdonate.file.model.FileDB;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.stream.Stream;

public interface FileService {
    public FileDB store(MultipartFile file) throws IOException;
    public FileDB getFile(String id);
    public Stream<FileDB> getAllFiles();
    public Stream<FileDB> getAllFileGif();
    public Stream<FileDB> getAllFileMp3();
}
