package com.nmcnpm.webdonate.texttospeech.message;

public class ResponseFileTextToSpeech {
    private  String name;
    private String type;
    private byte[] data;

    public ResponseFileTextToSpeech() {
    }

    public ResponseFileTextToSpeech( String name,String type, byte[] data) {
        this.name = name;
        this.type = type;
        this.data = data;
    }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public byte[] getData() {
        return data;
    }
    public void setData(byte[] data) {
        this.data = data;
    }
}
