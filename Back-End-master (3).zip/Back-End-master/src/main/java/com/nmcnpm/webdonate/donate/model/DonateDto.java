package com.nmcnpm.webdonate.donate.model;

import java.util.Date;

public class DonateDto {
    public static final int MOMO = 1;
    public static final int BANK = 0;

    private int type;
    private String name;
    private String money;
    private String content;
    private String bankingNumber;
    private String date;

    public DonateDto() {
        this.name = "HUST_ERS";
        this.money = "1.000.000.000";
        this.content = "Chào mừng mọi người đến với livestream. Donate để giúp Rip có tiền lấy vợ nhé";
    }

    public DonateDto(int type, String name, String money, String content, String bankingNumber, String date) {
        this.type = type;
        this.name = name;
        this.money = money;
        this.content = content;
        this.bankingNumber = bankingNumber;
        this.date = date;
    }

    public String getDonateMomo(){
        String mes = "cam on ban " + name + " da donate cho NAM TT " + money + "d qua MOMO";
        return mes;
    }

    public String ToString(){
        return name + "--" + money + "--" + content + "--" + type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBankingNumber() {
        return bankingNumber;
    }

    public void setBankingNumber(String bankingNumber) {
        this.bankingNumber = bankingNumber;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
