package com.nmcnpm.webdonate.setting.model;

import javax.persistence.*;

@Entity
@Table(name = "setting")
public class Setting {

    public Setting(int id, String template, String gifUrl, String soundUrl, int textStyleId,
                   long money, boolean ShopTopDonation, int AlertDuration, int AlertTextDelay) {
        this.Id = id;
        this.Template = template;
        this.GifUrl = gifUrl;
        this.SoundUrl = soundUrl;
        this.TextStyleId = textStyleId;
        this.Money = money;

        this.ShopTopDonation = ShopTopDonation;
        this.AlertDuration = AlertDuration;
        this.AlertTextDelay = AlertTextDelay;
    }

    public Setting() {
    }

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;
    private String Template;
    private String GifUrl;
    private String SoundUrl;
    private int TextStyleId;
    private long Money;
    private boolean ShopTopDonation;
    private int AlertDuration;
    private int AlertTextDelay;




    public boolean isShopTopDonation() { return ShopTopDonation; }

    public void setShopTopDonation(boolean shopTopDonation) { ShopTopDonation = shopTopDonation; }

    public int getAlertDuration() { return AlertDuration; }

    public void setAlertDuration(int alertDuration) { AlertDuration = alertDuration; }

    public int getAlertTextDelay() { return AlertTextDelay; }

    public void setAlertTextDelay(int alertTextDelay) { AlertTextDelay = alertTextDelay; }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        this.Id = id;
    }

    public String getTemplate() {
        return Template;
    }

    public void setTemplate(String template) {
        this.Template = template;
    }

    public String getGifUrl() {
        return GifUrl;
    }

    public void setGifUrl(String gifUrl) {
        GifUrl = gifUrl;
    }

    public String getSoundUrl() {
        return SoundUrl;
    }

    public void setSoundUrl(String soundUrl) {
        SoundUrl = soundUrl;
    }

    public int getTextStyleId() {
        return TextStyleId;
    }

    public void setTextStyleId(int textStyleId) {
        TextStyleId = textStyleId;
    }

    public long getMoney() {
        return Money;
    }

    public void setMoney(long money) {
        Money = money;
    }
}