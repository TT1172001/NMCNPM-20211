package com.nmcnpm.webdonate.apicontroller;

import com.google.gson.Gson;
import com.nmcnpm.webdonate.donate.entity.BankClient;
import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.entity.MomoClient;
import com.nmcnpm.webdonate.donate.mapstruct.MapStructMapper;
import com.nmcnpm.webdonate.donate.model.DonateDto;
import com.nmcnpm.webdonate.donate.service.DonateService;
import com.nmcnpm.webdonate.donate.service.MomoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.util.LinkedList;
import java.util.Queue;

@Controller
public class ApiController {
    Queue<String> queueMessage;
    boolean session;
    public ApiController(){
        session = true;
        queueMessage = new LinkedList<String>();
    }

    @Autowired
    private MapStructMapper mapStructMapper;
    @Autowired
    private MomoService momoService;
    @Autowired
    private DonateService donateService;

    @MessageMapping("/hello")
    @SendTo("/topic/message")
    public String message(@Payload String mes) {
        DonateDto donateDto = dataToDonate(mes);
        return new Gson().toJson(donateDto);
    }

    private DonateDto dataToDonate(String data){
        if(data.equals("Hust.edu.vn")){
            return new DonateDto();
        }
        else {
            DonateDto donateDto = mapStructMapper.dataToDonateDto(data);
            if (donateDto.getType() == DonateDto.MOMO) {
                MomoClient momoClient = mapStructMapper.donateDtoToMomoClient(donateDto);
                Donate donate = mapStructMapper.donateDtoMomoToDonate(donateDto, momoClient);
                if (!momoService.checkID(momoClient.getNameId())) {
                    momoService.saveMomo(momoClient);
                }
                donateService.saveDonate(donate);
            }
            return donateDto;
        }
    }
}
