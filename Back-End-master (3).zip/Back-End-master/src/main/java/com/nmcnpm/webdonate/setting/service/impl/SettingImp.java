package com.nmcnpm.webdonate.setting.service.impl;

import com.nmcnpm.webdonate.setting.model.Setting;
import com.nmcnpm.webdonate.setting.repository.SettingCurdRepository;
import com.nmcnpm.webdonate.setting.repository.SettingRepository;
import com.nmcnpm.webdonate.setting.service.SettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SettingImp implements SettingService {

    @Autowired
    SettingRepository settingRepository;

    @Autowired
    SettingCurdRepository settingCurdRepository;

    @Override
    public Setting saveSetting(Setting setting){
        return settingRepository.save(setting);
    }

    @Override
    public void deleteSetting(int id){
        settingRepository.deleteById(id);
    }

    @Override
    public boolean editSetting(Setting setting) {
        Setting edit = settingRepository.getById(setting.getId());
        setting.setSoundUrl(edit.getSoundUrl());
        setting.setGifUrl(edit.getGifUrl());
        settingRepository.save(setting);
        return true;
    }

    @Override
    public List<Setting> getAllSetting() {
        return settingRepository.findAll();
    }
}