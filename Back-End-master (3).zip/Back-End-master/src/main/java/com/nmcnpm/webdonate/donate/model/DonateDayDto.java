package com.nmcnpm.webdonate.donate.model;

public class DonateDayDto {
    private int day;
    private long  total_donate;

    public DonateDayDto(int day, long total_donate) {
        this.day=day;
        this.total_donate=total_donate;
    }

    public int getDay() {
        return day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public long getTotal_donate() {
        return total_donate;
    }
    public void setTotal_donate(long total_donate) {
        this.total_donate = total_donate;
    }
}
