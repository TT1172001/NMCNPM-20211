package com.nmcnpm.webdonate.donate.mapstruct;

import com.nmcnpm.webdonate.donate.entity.BankClient;
import com.nmcnpm.webdonate.donate.entity.Donate;
import com.nmcnpm.webdonate.donate.entity.MomoClient;
import com.nmcnpm.webdonate.donate.model.BankingDonateDto;
import com.nmcnpm.webdonate.donate.model.DonateAllDto;
import com.nmcnpm.webdonate.donate.model.DonateDto;
import com.nmcnpm.webdonate.donate.model.MomoDonateDto;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
public  class MapStructMapperImpl implements MapStructMapper {
    @Override
    public MomoDonateDto donateToMomoDonateDto(Donate donate) {
        if ( donate == null ) {
            return null;
        }
        MomoDonateDto momoDonateDto = new MomoDonateDto();

        momoDonateDto.setNameID_Momo(donate.getNameDonate().getNameId());
        momoDonateDto.setMoney(donate.getMoney());

        Calendar cal = Calendar.getInstance();
        cal.setTime(donate.getDate());

        momoDonateDto.setDay(cal.get(Calendar.DAY_OF_MONTH));
        momoDonateDto.setMonth(cal.get(Calendar.MONTH)+1);
        momoDonateDto.setYear(cal.get(Calendar.YEAR));

        return momoDonateDto;
    }

    @Override
    public List<MomoDonateDto> donatesToMomoDonateDtos(List<Donate> donates){
        if ( donates == null ) {
            return null;
        }

        List<MomoDonateDto> list = new ArrayList<MomoDonateDto>( donates.size() );
        for ( Donate donate : donates ) {
            list.add( donateToMomoDonateDto(donate) );
        }
        return list;
    }
    @Override
    public BankingDonateDto donateToBankingDonateDto(Donate donate) {
        if ( donate == null ) {
            return null;
        }
        BankingDonateDto bankingDonateDto = new BankingDonateDto();

        bankingDonateDto.setName_banking(donate.getBankingNumber().getName());
        bankingDonateDto.setBanking_number(donate.getBankingNumber().getBankingNumber());
        bankingDonateDto.setMoney(donate.getMoney());

        Calendar cal = Calendar.getInstance();
        cal.setTime(donate.getDate());

        bankingDonateDto.setDay(cal.get(Calendar.DAY_OF_MONTH));
        bankingDonateDto.setMonth(cal.get(Calendar.MONTH)+1);
        bankingDonateDto.setYear(cal.get(Calendar.YEAR));

        return bankingDonateDto;
    }

    @Override
    public List<BankingDonateDto> donatesToBankingDonateDtos(List<Donate> donates){
        if ( donates == null ) {
            return null;
        }

        List<BankingDonateDto> list = new ArrayList<BankingDonateDto>( donates.size() );
        for ( Donate donate : donates ) {
            list.add( donateToBankingDonateDto(donate) );
        }
        return list;
    }

    @Override
    public DonateDto dataToDonateDto(String data) {
        if(data == null){
            return null;
        }
        if(data.startsWith("Nhận")){
            DonateDto donateDto = new DonateDto();
            donateDto.setMoney(data.substring(5, data.indexOf("đ")));
            donateDto.setName(data.substring(data.indexOf("từ") + 3, data.indexOf("/r/n")));
            try {
                donateDto.setContent(data.substring(data.indexOf("\"") + 1, data.indexOf("\"", data.indexOf("\"") + 1)));
            }
            catch (Exception e){
                donateDto.setContent(null);
            }
            if(data.endsWith("1")){
                donateDto.setType(DonateDto.MOMO);
            }
            else {
                donateDto.setType(DonateDto.BANK);
            }
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss");
            Date date = new Date();
            donateDto.setDate(formatter.format(date));

            return donateDto;
        }
        return null;
    }

    @Override
    public BankClient donateDtoToBankClient(DonateDto donateDto) {
        BankClient bankClient = new BankClient();
        bankClient.setBankingNumber(donateDto.getBankingNumber());
        bankClient.setName(donateDto.getName());
        bankClient.setStatus(true);
        return bankClient;
    }

    @Override
    public Donate donateDtoMomoToDonate(DonateDto donateDto, MomoClient momoClient) {
        Donate donate = new Donate();
        donate.setContent(donateDto.getContent());
        donate.setMoney((long)Integer.valueOf(formatMoney(donateDto.getMoney())));
        donate.setNameDonate(momoClient);
        try {
            donate.setDate(new SimpleDateFormat("dd/MM/yyyy  HH:mm:ss").parse(donateDto.getDate()));
        } catch (ParseException e) {
            donate.setDate(null);
        }
        return donate;
    }

    @Override
    public MomoClient donateDtoToMomoClient(DonateDto donateDto) {
        MomoClient momoClient = new MomoClient();
        momoClient.setNameId(donateDto.getName());
        momoClient.setStatus(true);
        return momoClient;
    }

    private String formatMoney(String money) {
        for (int i = 0; i < money.length(); i++) {
            if (money.charAt(i) == '.') {
                money = money.substring(0, i) + money.substring(i + 1);
            }
        }
        return money;
    }

}