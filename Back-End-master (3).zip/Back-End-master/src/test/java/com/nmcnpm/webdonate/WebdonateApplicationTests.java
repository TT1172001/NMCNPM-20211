package com.nmcnpm.webdonate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebdonateApplicationTests {

	@Test
	void contextLoads() {
	}

}
